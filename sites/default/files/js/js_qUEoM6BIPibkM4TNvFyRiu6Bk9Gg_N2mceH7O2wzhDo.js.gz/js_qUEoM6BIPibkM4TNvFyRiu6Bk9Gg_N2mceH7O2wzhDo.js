$(document).ready(function() {
  console.log('Could you improve me please?');
});
;
